
import org.apache.log4j.BasicConfigurator
import org.apache.log4j.varia.NullAppender
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.streaming.Trigger

object KafkaConsumer_tweets {

  def main(args: Array[String]): Unit = {

    val nullAppender = new NullAppender
    BasicConfigurator.configure(nullAppender)

    val spark = SparkSession
      .builder
      .master("local[8]")
      .appName("KafkaConsumer_tweets")
      .getOrCreate()

    import spark.implicits._

    spark.conf.set("spark.sql.shuffle.partitions", 2)

    val df = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "[BigdataProject]")
      .load()

    val df1 = df
      .selectExpr("CAST(value AS STRING)")
      .select(functions.json_tuple($"value", "id", "date", "user", "text", "retweets"))
      .toDF("id", "date", "user", "text", "retweets")

    // Define MongoDB connection options
    val mongodbOptions = Map(
      "uri" -> "mongodb://localhost:27017",
      "database" -> "tweets",
      "collection" -> "tweets"
    )
    // Write data to MongoDB using foreachBatch
    val query = df1.writeStream
      .outputMode("append")
      .trigger(Trigger.ProcessingTime("5 seconds"))
      .foreachBatch { (batchDF: org.apache.spark.sql.Dataset[org.apache.spark.sql.Row], batchId: Long) =>
        batchDF
          .write
          .format("com.mongodb.spark.sql")
          .mode("append")
          .options(mongodbOptions)
          .save()
      }
      .start()


    query.awaitTermination()
  }
}
