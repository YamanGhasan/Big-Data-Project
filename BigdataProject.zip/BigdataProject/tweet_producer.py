import zipfile
import time
import random
from time import sleep
import json
from kafka import KafkaProducer

# Initialize Kafka producer
producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    api_version=(0, 11, 5),
    value_serializer=lambda x: json.dumps(x).encode('utf-8')
)

counter = 0

with zipfile.ZipFile('C:/Users/user/Downloads/archive.zip', 'r') as z:
    with z.open(z.namelist()[0]) as f:
        for line in f:
            try:
                line = line.decode('utf-8', errors='replace').replace('\ufffd', '')
            except UnicodeDecodeError as e:
                print(f"Skipping line due to decoding error: {e}")
                continue

            # Your existing code for processing the line goes here
            attribute_details = line.split(',')
            tweet = {
                "id": attribute_details[1],
                "date": int(time.time() * 1000),
                "user": attribute_details[4],
                "text": attribute_details[5],
                "retweets": int(random.random() * 10)
            }

            # Print the tweet for debugging
            print(tweet)

            # Publish tweet to Kafka topic
            try:
                producer.send('BigdataProject', value=tweet)
                print("Tweet sent to Kafka")
            except Exception as e:
                print(f"Error sending message to Kafka: {e}")

            # Increment the counter
            counter += 1

            # Add a sleep if needed
            sleep(1)

# Close the Kafka producer
producer.close()



 