 
 
from datetime import datetime
from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient
from bson import json_util

app = Flask(__name__)
client = MongoClient("mongodb://localhost:27017")  
db = client["tweets"]  
tweets_collection = db["tweets"]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_top_users')
def get_top_users():
    # Retrieve top 20 users based on the number of published tweets
    top_users = tweets_collection.aggregate([
        {"$group": {"_id": "$user", "tweet_count": {"$sum": 1}}},
        {"$sort": {"tweet_count": -1}},
        {"$limit": 20}
    ])
    top_users_data = [{"user": user["_id"], "tweet_count": user["tweet_count"]} for user in top_users]
    return jsonify(top_users_data)

import re


from datetime import datetime

@app.route('/data')
def get_filtered_data():
    user_query = request.args.get('user')
    print('User Query:', user_query)
 
    user_query = user_query.strip('"')

 
    regex_query = re.compile(re.escape(user_query), re.IGNORECASE)

  
    tweets = tweets_collection.find({'user': regex_query})

     
    raw_data = list(tweets)
    print('Raw Data from MongoDB:', raw_data)

 
    tweet_data = {}
    for tweet in raw_data:
       
        tweet_date = datetime.strptime(tweet['Date'], '%Y-%m-%d %H:%M:%S').date()

        
        day = tweet_date.strftime('%Y-%m-%d')

       
        tweet_data[day] = tweet_data.get(day, 0) + 1

    
    chart_data = [{'date': day, 'count': count} for day, count in tweet_data.items()]

    return jsonify(chart_data)


if __name__ == '__main__':
    app.run(debug=True, port=5001)
